import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Auth from './components/Auth';
import Products from './components/Products'; // Import your Products component

function App() {
  return (
    <Router>
      <div>
        <Routes>
          <Route path="/auth" element={<Auth />} />
          <Route path="/products" element={<Products />} /> 
        </Routes>
      </div>
    </Router>
  );
}

export default App;
